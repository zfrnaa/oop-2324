package proj.g8;

//Represents a booking for a bicycle rental.
//Stores the booking ID, date, customer, and bicycle associated with the booking.
public class Booking
{
    //The unique identifier of the booking.
    private int id;

    //The date of the booking.
    private String date;

    //The customer who made the booking.
    private Customer customer;

    //The bicycle that has been booked.
    private Bicycle bicycle;

    /**
     * Creates a new Booking object with the specified details.
     *
     * @param id       The unique ID of the booking.
     * @param date     The date of the booking.
     * @param customer The customer making the booking.
     * @param bicycle  The bicycle being booked.
     */
    public Booking(int id, String date, Customer customer, Bicycle bicycle)
    {
        this.id = id;
        this.date = date;
        this.customer = customer;
        this.bicycle = bicycle;
    }

    //Gets and return the ID of the booking.
    public int getId()
    {
        return id;
    }

    //Gets and return the date of the booking.
    public String getDate()
    {
        return date;
    }

    //Gets and return the customer who made the booking.
    public Customer getCustomer()
    {
        return customer;
    }

    //Gets and return the bicycle that has been booked.
    public Bicycle getBicycle()
    {
        return bicycle;
    }

    public static String getBookingOverview() {
        StringBuilder sb = new StringBuilder();
        sb.append("Available Bicycle:\n");
        for (Booking booking : RentingSystem.bookings) {
            sb.append(booking).append("\n\n");
        }
        return sb.toString();
    }

    // Returns a string representation of the Booking object, including its ID, date, customer, and bicycle.
    @Override
    public String toString()
    {
        return "Booking ID: " + getId() + "\nDate of Booking: " + getDate() + "\n" + getCustomer() +
               "\n" + getBicycle();
    }
}
