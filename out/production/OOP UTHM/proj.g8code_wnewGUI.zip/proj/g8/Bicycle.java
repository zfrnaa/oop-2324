package proj.g8;

 //Represents a bicycle in the renting system.
 //Stores the bicycle's unique ID and model.
public class Bicycle
{
    //The unique identifier of the bicycle.
    private int id;

    //The model of the bicycle.
    private String model;

    //Creates a new Bicycle object with the specified ID and model.
    public Bicycle(int id, String model)
    {
        this.id = id;
        this.model = model;
    }

    //Gets and return the ID of the bicycle.
    public int getId()
    {
        return id;
    }

    //Gets the model and return the bicycle.
    public String getModel()
    {
        return model;
    }

    public static String getBicycleOverview() {
        StringBuilder sb = new StringBuilder();
        sb.append("Available Bicycle:\n");
        for (Bicycle bicycle : RentingSystem.bicycles) {
            sb.append(bicycle).append("\n\n");
        }
        return sb.toString();
    }


    // Returns a string representation of the Bicycle object, including its ID and model.
    @Override
    public String toString()
    {
        return "Bicycle ID: " + id + "\nType: " + model + "\uD83D\uDEB2";
    }
}
