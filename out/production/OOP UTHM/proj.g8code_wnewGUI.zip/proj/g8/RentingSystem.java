/*
Made by group 8

ZAFRAN (CI220132)
ALIAH (CI220109)
SYASYA (CI220064)
ATIKAH (CI220027)
SOLEHAH (CI220038)

Checked and edited by
Zafran

*/

package proj.g8;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class RentingSystem
{
    protected static final ArrayList<Customer> customers = new ArrayList<>();
    protected static final ArrayList<Bicycle> bicycles = new ArrayList<>();
    protected static final ArrayList<Booking> bookings = new ArrayList<>();
    private static JTextField customerNameField, customerIdField, bicycleIdField,
            bookingIdField, bookingDateField;

    public static JFrame frame;

    public static void main(String[] args)
    {
        BicycleRentingSystem.confirmUser();
    }

    public static void createObjects()
    {
        frame = new JFrame("Bicycle renting");
        JPanel panel = new JPanel(new GridBagLayout()); // Using GridBagLayout for flexibility
        GridBagConstraints c = new GridBagConstraints();

        // Customer labels and fields
        c.gridx = 0;
        c.gridy = 0;
        panel.add(new JLabel("Customer Name:"), c);
        c.gridx = 1;
        customerNameField = new JTextField(20);
        customerNameField.setForeground(Color.BLUE);
        panel.add(customerNameField, c); // Add the text field to the panel

        c.gridx = 0;
        c.gridy = 1;
        panel.add(new JLabel("Customer ID:"), c);
        c.gridx = 1;
        customerIdField = new JTextField(20);
        customerIdField.setForeground(Color.BLUE);
        panel.add(customerIdField, c); // Add the text field to the panel

        // Bicycle labels and fields
        c.gridx = 0;
        c.gridy = 2;
        panel.add(new JLabel("Bicycle Types:"), c);
        c.gridx = 1;
        String[] bicyleMOptions = {"Mountain", "BMX", "Electric", "Folding", "City"};
        // Create a JComboBox and add the options
        JComboBox<String> comboBox = new JComboBox<>(bicyleMOptions);
        comboBox.setForeground(Color.BLUE);
        panel.add(comboBox, c); // Add the text field to the panel


        c.gridx = 0;
        c.gridy = 3;
        panel.add(new JLabel("Bicycle ID:"), c);
        c.gridx = 1;
        bicycleIdField = new JTextField(20);
        bicycleIdField.setForeground(Color.BLUE);
        panel.add(bicycleIdField, c); // Add the text field to the panel

        // Booking labels and fields
        c.gridx = 0;
        c.gridy = 4;
        panel.add(new JLabel("Booking ID:"), c);
        c.gridx = 1;
        bookingIdField = new JTextField(20);
        bookingIdField.setForeground(Color.BLUE);
        panel.add(bookingIdField, c); // Add the text field to the panel

        c.gridx = 0;
        c.gridy = 5;
        panel.add(new JLabel("Booking Date:"), c);
        c.gridx = 1;
        bookingDateField = new JTextField(20);
        bookingDateField.setForeground(Color.BLUE);
        panel.add(bookingDateField, c); // Add the text fields to the panel

        // Create button
        JButton createButton = new JButton("Book bicycle");
        createButton.addActionListener(e -> bookBicycleFromGUI(
                Objects.requireNonNull(comboBox.getSelectedItem()).toString()));
        c.gridx = 0;
        c.gridy = 6;
        c.gridwidth = 2;
        panel.add(createButton, c);

        frame.add(panel);
        frame.pack();
        frame.setSize(360,240);
        frame.setLocation(600,260);
        frame.setVisible(true);
    }

    public static void bookBicycleFromGUI(String bicycleMOptions)
    {
        try
        {
            String customerName = customerNameField.getText();
            int customerId = Integer.parseInt(customerIdField.getText());
            int bicycleId = Integer.parseInt(bicycleIdField.getText());
            int bookingId = Integer.parseInt(bookingIdField.getText());
            String bookingDate = bookingDateField.getText();

            Customer customer = new Customer(customerId, customerName);
            customers.add(customer);
            Bicycle bicycle = new Bicycle(bicycleId, bicycleMOptions);
            bicycles.add(bicycle);
            Booking booking = new Booking(bookingId, bookingDate, customer, bicycle);
            bookings.add(booking);

            JOptionPane.showMessageDialog(frame, "Bicycle booked!");
        } catch (NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(frame,
                                          "Invalid input. Please enter valid numbers for IDs.",
                                          "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void displayInfoMenu()
    {
        boolean validChoice = false;
        while (! validChoice)
        {
            String displayChoice = JOptionPane.showInputDialog(null,
                                                               "Choose information to display: \n1. Customers\n2. Bicycles\n3. Bookings",
                                                               "Your choice",
                                                               JOptionPane.QUESTION_MESSAGE);
            int choice = Integer.parseInt(displayChoice);
            if (choice >= 1 && choice <= 3)
            {
                validChoice = true;
                switch (choice)
                {
                    case 1:
                        for (Customer customer : customers)
                        {
                            String customerOverview = customer.getCustomerOverview();
                            JOptionPane.showMessageDialog(null, customerOverview, "Customer Information",
                                                          JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 2:
                        for (Bicycle bicycle : bicycles)
                        {
                            String bicycleOverview = bicycle.getBicycleOverview();
                            JOptionPane.showMessageDialog(null, bicycleOverview, "Booked Bicycle Information",
                                                          JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 3:
                        for (Booking booking : bookings)
                        {
                            String bookingOverview = booking.getBookingOverview();
                            JOptionPane.showMessageDialog(null, bookingOverview, "Booking Information",
                                                          JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    default:
                        String errorMessage = "Invalid choice. Please enter a number between 1 and 3.";
                        JOptionPane.showMessageDialog(null, errorMessage, "Error option",
                                                      JOptionPane.ERROR_MESSAGE);

                }
            } else
            {
                JOptionPane.showMessageDialog(null,
                                              "Invalid choice. Please enter a number between 1 and 3.",
                                              "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void searchCustomerByName()
    {
        String searchNameField = JOptionPane.showInputDialog(null, "Search the customer name",
                                                             "Searching section",
                                                             JOptionPane.QUESTION_MESSAGE);
        try
        {
            // Perform the search logic using your customers data
            // For example, iterating through the customers list and comparing names:
            Customer foundCustomer = null;
            Bicycle fcBicycle = null;
            for (Booking booking : bookings)
            {
                if (booking.getCustomer().getName().equalsIgnoreCase(searchNameField))
                {
                    foundCustomer = booking.getCustomer();
                    fcBicycle = booking.getBicycle();
                    break;
                }
            }

            if (foundCustomer != null)
            {
                // Display search results (e.g., using a message dialog or updating a separate panel)
                JOptionPane.showMessageDialog(frame, "Customer found!" + "\nBicycle information:\n" + fcBicycle);

            } else
            {
                JOptionPane.showMessageDialog(frame, "Customer not found.");
            }
        } catch (Exception ex)
        {
            // Handle any errors that might occur during the search
            JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "Search Error",
                                          JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void updateCustomerName()
    {
        String[] customerNames = customers.stream().map(Customer::getName).toArray(String[]::new);
        String selectedCustomer = (String) JOptionPane.showInputDialog(
                null,
                "Select the customer to update:",
                "Choose Customer",
                JOptionPane.QUESTION_MESSAGE,
                null,
                customerNames,
                customerNames[0] // Default selection
        );

        if (selectedCustomer != null) {
            for (Customer customer : customers) {
                if (customer.getName().equals(selectedCustomer)) {
                    String updatedName = JOptionPane.showInputDialog(null, "Enter the new name:");
                    if (updatedName != null) {
                        customer.setName(updatedName);
                        JOptionPane.showMessageDialog(null, "Customer name updated!", "Status", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    }
                }
            }
        }
    }

    static void removeBicycle()
    {

        String bicycleModel = JOptionPane.showInputDialog(null, "Enter bicycle model to remove:");

        if (bicycleModel != null && ! bicycleModel.isEmpty())
        {
            boolean bicycleFound = false;
            for (Bicycle bicycle : bicycles)
            {
                if (bicycle.getModel().equalsIgnoreCase(bicycleModel))
                {
                    bicycles.clear();
                    JOptionPane.showMessageDialog(null, "Customer's bicycle type removed successfully.");
                    bicycleFound = true;
                    break;
                }
            }

            if (! bicycleFound)
            {
                JOptionPane.showMessageDialog(null, "Bicycle not found.", "Error",
                                              JOptionPane.ERROR_MESSAGE);
            }
        } else
        {
            JOptionPane.showMessageDialog(null, "Please enter a valid bicycle model.",
                                          "Invalid Input", JOptionPane.WARNING_MESSAGE);
        }
    }

    @Override
    public String toString()
    {
        return super.toString();
    }
}

class BicycleRentingSystem extends RentingSystem
{

    private static final Scanner input = new Scanner(System.in);

    public BicycleRentingSystem()
    {
        System.out.println("Hello there");
    }

    public static void confirmUser()
    {
        System.out.print("Are you a student? (y/n): ");
        String response = input.next().toLowerCase();
        if (response.equals("y"))
        {
            displayMenuGUI();
        } else
        {
            System.out.println(
                    "This system is only for UTHM student's only. Only student can access the bicycle renting system.");
            System.exit(0);
        }
    }

    public static void displayMenuGUI()
    {

        // Create a simple GUI window
        JFrame frame = new JFrame("UTHM Bicycle Renting System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JButton createButton = new JButton("Book bicycle");
        JButton displayButton = new JButton("Display Information");
        JButton searchButton = new JButton("Search Customer");
        JButton updateButton = new JButton("Update Customer Name");
        JButton removeButton = new JButton("Remove Customer's Bicycle Type");


        // Set layout and add    components
        frame.setLayout(new GridLayout(0, 1)); // Arrange buttons vertically
        frame.add(createButton);
        frame.add(displayButton);
        frame.add(searchButton);
        frame.add(updateButton);
        frame.add(removeButton);

        frame.setLocation(540,260);
        frame.setSize(480, 240);
        frame.setVisible(true);
        // Event listeners for buttons
        createButton.addActionListener(e -> createObjects());
        displayButton.addActionListener(e -> displayInfoMenu());
        searchButton.addActionListener(e -> searchCustomerByName());
        updateButton.addActionListener(e -> updateCustomerName());
        removeButton.addActionListener(e -> removeBicycle());
    }
}